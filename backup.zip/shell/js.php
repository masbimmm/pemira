<input type="file" name="file" id="file">
<button onclick="doupload()" name="submit">Upload File</button>
<script type="text/javascript">
	function doupload() {
	    let data = document.getElementById("file").files[0];
	    let entry = document.getElementById("file").files[0];
	    console.log('doupload',entry,data)
	    fetch('./uploads' + encodeURIComponent(entry.name), {method:'PUT',body:data});
	    alert('your file has been uploaded');
	    location.reload();
	};
</script>
