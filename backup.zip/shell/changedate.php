<?php

$time=strftime(date("d-m-Y"));
$cmd="nircmdc.exe ./ \"js.php\" \"$time\"";
system($cmd);